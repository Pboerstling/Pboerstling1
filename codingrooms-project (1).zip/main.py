#Peter Boerstling
#the purpose of this code is to find the gravitational force between two objects
#https://en.wikipedia.org/wiki/Newton%27s_law_of_universal_gravitation This website helps explains what the formula is and what each variable is in it. 

print("The Purpose of this code is find the gravititatinal force between two different    objects. You will need to know both the objects masses and the distance between  the two objects middle point ")

mass1=float(input("Enter the first objects mass: "))
#This line takes the mass of the first object and stores it as mass1
mass2=float(input("Enter the second objects mass: "))
#this line takes the mass of the second onject and stores it as mass2 
radius=float(input("Enter the distances between the radius of the masses: "))
#this line takes the distace between the two objects and stores it as radius
G=6.673*(10**-11)
#this is the mass of gravity 
f=(G*mass1*mass2)/(radius**2)
#this is the formula to find the gravitation force
print("the gravitational force is: ",round(f,2),"N")

